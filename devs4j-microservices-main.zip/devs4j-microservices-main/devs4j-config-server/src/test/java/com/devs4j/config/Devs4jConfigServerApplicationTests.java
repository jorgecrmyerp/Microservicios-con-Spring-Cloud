package com.devs4j.config;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Devs4jConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
