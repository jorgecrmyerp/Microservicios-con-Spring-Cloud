package com.devs4j.cloudstream;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Devs4jCloudstreamExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
