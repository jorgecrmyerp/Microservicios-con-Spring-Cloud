package com.devs4j.gateway;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Devs4jSpringGatewayLiveApplicationTests {

	@Test
	void contextLoads() {
	}

}
