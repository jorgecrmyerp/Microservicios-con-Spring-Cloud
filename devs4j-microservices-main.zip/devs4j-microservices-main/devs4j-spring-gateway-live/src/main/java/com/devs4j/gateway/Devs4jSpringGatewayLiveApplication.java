package com.devs4j.gateway;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Devs4jSpringGatewayLiveApplication {

	public static void main(String[] args) {
		SpringApplication.run(Devs4jSpringGatewayLiveApplication.class, args);
	}

}
