package com.devs4j.eureka;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Devs4jEurekaServerLiveApplicationTests {

	@Test
	void contextLoads() {
	}

}
