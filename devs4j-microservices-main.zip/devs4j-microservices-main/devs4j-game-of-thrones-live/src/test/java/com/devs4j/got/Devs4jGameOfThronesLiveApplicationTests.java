package com.devs4j.got;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Devs4jGameOfThronesLiveApplicationTests {

	@Test
	void contextLoads() {
	}

}
