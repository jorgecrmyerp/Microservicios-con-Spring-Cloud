package com.devs4j.got;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Devs4jGameOfThronesLiveApplication {

	public static void main(String[] args) {
		SpringApplication.run(Devs4jGameOfThronesLiveApplication.class, args);
	}

}
