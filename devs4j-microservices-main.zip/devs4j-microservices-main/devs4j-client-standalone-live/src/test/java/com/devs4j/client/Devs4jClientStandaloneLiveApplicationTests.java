package com.devs4j.client;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Devs4jClientStandaloneLiveApplicationTests {

	@Test
	void contextLoads() {
	}

}
