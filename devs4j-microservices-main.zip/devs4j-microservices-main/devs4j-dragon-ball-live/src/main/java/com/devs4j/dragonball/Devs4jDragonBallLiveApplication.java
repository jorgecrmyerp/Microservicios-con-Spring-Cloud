package com.devs4j.dragonball;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Devs4jDragonBallLiveApplication {

	public static void main(String[] args) {
		SpringApplication.run(Devs4jDragonBallLiveApplication.class, args);
	}

}
