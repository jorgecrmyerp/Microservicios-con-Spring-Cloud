package com.devs4j.dragonball;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Devs4jDragonBallFailoverLiveApplicationTests {

	@Test
	void contextLoads() {
	}

}
