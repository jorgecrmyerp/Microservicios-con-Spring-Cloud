package com.devs4j.auth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Devs4jAuthServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
