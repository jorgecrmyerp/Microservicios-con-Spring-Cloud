package com.devs4j.auth;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Devs4jAuthServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(Devs4jAuthServiceApplication.class, args);
	}

}
